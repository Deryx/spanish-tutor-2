import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Vocabulary } from '../vocabulary';

const apiUrl = 'https://h9e4pkcg77.execute-api.us-east-2.amazonaws.com/dev/words';

@Injectable()
export class VocabularyService {
  constructor( private http: HttpClient ){}

  getDictionary(){
    const uri = 'https://a7pz66xhek.execute-api.us-east-2.amazonaws.com/services-dev/retrieveAllVocabulary';
    return this.http
      .get( uri )
      .pipe(map( 
        function(res){
          return res;
      }));
  }

  getCategory( category: string ){
    const uri = apiUrl + '/category/:' +  category;
    return this.http
      .get( uri )
      .pipe(map( 
        function(res){
          return res;
      }));
  }

  addWord( newWord: Vocabulary ){
    const uri = apiUrl;
    return this.http
      .post( uri, newWord )
  }
}
