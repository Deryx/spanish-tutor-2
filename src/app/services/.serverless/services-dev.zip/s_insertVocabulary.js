var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'deryx',
applicationName: 'services-dev',
appUid: 'Qv9lHG9d9JyTqXtb7G',
orgUid: '1wt4RTZVM2TNbqlDcK',
deploymentUid: '60368b74-1bda-4324-a09d-1a9520f27076',
serviceName: 'services-dev',
stageName: 'services-dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'services-dev-services-dev-insertVocabulary', timeout: 6}
try {
  const userHandler = require('./insertVocabulary.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
