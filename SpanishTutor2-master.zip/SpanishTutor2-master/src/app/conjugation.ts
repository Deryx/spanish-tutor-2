export class Conjugation {
  tense: string;
  yo: string;
  tu: string;
  el: string;
  nosotros: string;
  els: string;

  constructor() {
    this.tense = '';
    this.yo = '';
    this.tu = '';
    this.el = '';
    this.nosotros = '';
    this.els = '';
  }
}
