import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-letter-pronunciation',
  templateUrl: './letter-pronunciation.component.html',
  styleUrls: ['./letter-pronunciation.component.css']
})
export class LetterPronunciationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
